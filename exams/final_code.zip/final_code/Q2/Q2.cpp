#include <exception>

#include "Q2.h"

using namespace std;

// Q2a
Account::Account() {
	return;
}


// Q2b
Account::Account(int id, string owner, int balance) {
	return;
}


// Q2c
unsigned int Account::getId() {
	return 0;
}

void Account::setId(unsigned int id) {
	return;
}

string Account::getOwner() {
	return "";
}

void Account::setOwner(string owner) {
	return;
}

int Account::getBalance() {
	return 0;
}

void Account::setBalance(int balance) {
	return;
}


// Q2d
bool Account::enoughBalance(unsigned int x) {
	return 0;
}


// Q2e
void Account::withdraw(int x) {
	return;
}