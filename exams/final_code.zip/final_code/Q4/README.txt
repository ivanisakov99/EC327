Compile Q4 with:

g++ -std=c++11 Q4.cpp

File descriptions:
- Q4.cpp: Your solution!
- Q4sample.txt: This includes a log of interacting with the program by hand.
- Q4input.txt: A sample input txt file you can pipe into your program with "./a.out < Q4input.txt".
- Q4output.txt: The output of the above command if you run it as "./a.out < Q4input.txt > Q4output.txt".
- grocery_list.txt: The output grocery list file from the above command.
