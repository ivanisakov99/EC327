#include <iostream>
#include <fstream>
#include <list>
#include <string>

// Include any additional libraries you'd like up here...
// Remember your must use list as your primary data structure!

using namespace std;

// Define any helper functions you like up here...



int main(int argc, char * argv[]) {
	// Q4a
	// Declare your list here!
	

	// Q4b
	cout << "Type in a grocery item and hit enter to add to the list." << endl;
	cout << "Alternatively, type \"N\" and hit enter to exit this program." << endl;

	// Take in user input and parse it here!
	while (42) {
		// What goes in here?
		
	}

	// Q4c
	// Sort your list here!

	// Q4d
	// Do your file handling here!

	return 0;
}
