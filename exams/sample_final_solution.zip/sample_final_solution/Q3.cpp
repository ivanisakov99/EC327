#include "Q3.h"
#include <iostream>
using namespace std;

Car::Car(short year, string make, string color, unsigned int mileage){
	this->year = year;
	this->make = make;
	this->color = color;
	this->mileage = mileage;
}

Car::Car(const Car& car){
	this->year = car.year;
	this->make = car.make;
	this->color = car.color;
	this->mileage = 0;
}

void Car::setColor(string x){
	this->color = x;
}

string Car::getColor(){
	return this->color;
}

void Car::setMake(string x){
	this->make = x;
}

string Car::getMake(){
	return this->make;
}

void Car::move(){
	cout<< "A " << this->make << " drives" << endl;
}

